# Spring Boot Upload Files to Database example

For more detail, please visit:
> [Spring Boot Upload/Download File to/from Database example](https://bezkoder.com/spring-boot-upload-file-database/)

Front-end Apps to work with this Spring Boot Server:
- [Angular](https://bezkoder.com/angular-10-file-upload/)
- [Vue](https://bezkoder.com/vue-axios-file-upload/)
- [React](https://bezkoder.com/react-file-upload-axios/)

## Run Spring Boot application
```
mvn spring-boot:run
```
